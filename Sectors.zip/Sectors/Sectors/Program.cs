﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sectors
{
    public class Sector
    {

        private double angle;
        private double r;
        public double Angle
        {
            get { return angle; }
            set
            {
                if (value <= 0 || value > 360)
                    throw new ArgumentOutOfRangeException("Angle must be > 0");
                else angle = value;
            }
        }
        public double R
        {
            get { return r; }
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException("Radius must be > 0");
                else r = value;
            }
        }
      

        public Sector()
        {
            Init(1.0, 1.0);
        }

        public Sector(double angle, double r)
        {
            Init(angle, r);
        }

        public Sector(Sector sector)
        {
            Init(sector.Angle, sector.R);
        }

        private void Init(double angle, double r)
        {
            Angle = angle;
            R = r;
        }

        public bool IsSectorEquals(Sector sector)
        {
            if (R == sector.R && Angle == sector.Angle) return true;
            else return false;
        }

        public void Input()
        {
            double angle = Convert.ToDouble(Console.ReadLine());
            double r = Convert.ToDouble(Console.ReadLine());

            Init(angle, r);
        }

        public void Print()
        {
            Console.WriteLine("angle = " + Angle + "\n" + "r = " + R + "\n");
        }

        public double GetPerimeter()
        {
            return 2 * Math.PI * R * Angle / 360;
        }

        public double GetArea()
        {
            return Math.PI * R * R * Angle / 360;
        }

        static void Main(string[] args)
        {
            Sector sector1 = new Sector();
            Sector sector2 = new Sector(1, 90);
            Console.WriteLine("Insert Sector 1 parameters " + "\n");
            sector1.Input();
            Console.WriteLine("Sector1 parameters are \n");
            sector1.Print();
            Console.WriteLine("Sector2 parameters are \n");
            sector2.Print();
            Console.WriteLine("Sector1 perimeter is " + Math.Round(sector1.GetPerimeter(), 3) + "\n");
            Console.WriteLine("Sector2 perimeter is " + Math.Round(sector2.GetPerimeter(), 3) + "\n");
            Console.WriteLine("Sector1 area is " + Math.Round(sector1.GetArea(), 3) + "\n");
            Console.WriteLine("Sector2 area is " + Math.Round(sector2.GetArea(), 3) + "\n");
            Console.WriteLine("is Sector1 and Sector2 Equals " + sector1.IsSectorEquals(sector2) + "\n");
            Console.ReadKey();
        }
    }
}
